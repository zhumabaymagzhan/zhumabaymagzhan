using TaskManagementAPI.Models;

namespace TaskManagementAPI.Repositories;

public interface ITaskRepository
{
    IEnumerable<BaseTask> GetAll();
    BaseTask? GetById(Guid id);
    void Add(BaseTask task);
    void Update(BaseTask task);
}